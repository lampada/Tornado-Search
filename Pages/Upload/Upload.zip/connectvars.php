<?php
//数据库的位置
define('DB_HOST', SAE_MYSQL_HOST_M);
//用户名
define('DB_USER', SAE_MYSQL_USER);
//口令
define('DB_PASSWORD', SAE_MYSQL_PASS);
//数据库名
define('DB_NAME','app_yosearch') ;
?>